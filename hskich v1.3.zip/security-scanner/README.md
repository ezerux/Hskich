# Հսկիչ (Hskich) — Local Security Audit Dashboard

Windows-ի համար նախատեսված local գործիք, որը՝
- սկանավորում է բացված (listening) ցանցային պորտերը և ստուգում firewall-ի կարգավիճակը
- ստուգում է հիմնական Windows anti-hardening կարգավորումները՝ UAC, RDP, SMBv1, Windows Update-ի թարմությունը, Guest հաշիվը, local admin-ների ցանկը, startup ծրագրերը
- ցույց է տալիս Windows Defender-ի կարգավիճակը (antivirus/real-time protection enabled, signature age) և թույլ է տալիս սկսել quick scan, ինչպես նաև, ընտրովի, ինտեգրվում է **ClamAV**-ի հետ՝ որպես երկրորդ antivirus engine (database update + on-demand scan)
- **Monitoring** — CPU/RAM/Disk/Network իրական ժամանակում, գրաֆիկներով, plus task-manager-ի նման ցանկ՝ ամեն պրոցեսի CPU%/RAM-ով, sortable
- **Reports** — սեղմելով «Generate report» ստանում ես ամբողջ սկանավորման summary, որը կարող ես print/Save as PDF անել կամ ներբեռնել որպես .txt
- Ամեն բաժնի կողքին կա small **⤢** կոճակ, որով բաժինը բացվում է առանձին browser tab-ում (հարմար է, օրինակ, Logs-ը մշտապես բաց պահելու համար)
- Dashboard-ի ամբողջ ինտերֆեյսը անգլերեն է
- հավաքում է վերջին Event Log գրառումները (System/Application errors, Security log-ից՝ failed logon-ներ, admin խմբում փոփոխություններ, account lockout-ներ)
- ամեն գտածո խնդրի համար տալիս է **priority (critical/high/medium/low)** և կոնկրետ առաջարկություն

Malware scanning-ի համար գործիքն օգտագործում է **already-built-in Windows Defender-ը** (PowerShell-ի `Get-MpComputerStatus`/`Start-MpScan` միջոցով) և, ցանկության դեպքում, **ClamAV**-ը՝ որպես երկրորդ, անկախ antivirus engine, այլ ոչ թե սեփական սկանավորման շարժիչ. Defender-ի և ClamAV-ի signature database-երը թարմացվում են ամեն օր հենց իրենց մշակողների կողմից, մինչդեռ ինքնուրույն գրված scanner-ը արագ կհնանա և հուսալի չի լինի։

### ClamAV (ընտրովի, բայց խորհուրդ ենք տալիս)

Dashboard-ը ինքնուրույն չի տեղադրում ClamAV-ը (մեծ ֆայլ է, առանձին installer ունի)։

1. Ներբեռնիր Windows-ի `.msi` installer-ը՝ https://www.clamav.net/download
2. Տեղադրիր (default path՝ `C:\Program Files\ClamAV`)
3. Dashboard-ի **Malware / Antivirus** էջում կերևա, որ ClamAV-ը հայտնաբերվել է. սեղմիր **«Թարմացնել ClamAV database-ը»**՝ առաջին անգամ virus definitions ներբեռնելու համար
4. Դրանից հետո կարող ես սեղմել **«Սկանավորել Downloads/Desktop/Temp»**՝ ամենառիսկային պանակները ստուգելու համար (կարող է տևել մի քանի րոպե)

Եթե ClamAV-ը տեղադրված չէ, dashboard-ը դա կնշի որպես info-մակարդակի finding, բայց ամբողջ մնացած սկանավորումը (ցանց, համակարգ, Defender, log-եր) կաշխատի առանց դրա։

## Ծրագրի (Desktop Software) գործարկում

Այժմ ծրագիրը կարող է աշխատել ինչպես իսկական **Desktop Ծրագիր (Standalone Soft)**՝ առանց բրաուզերի հասցեի տողի կամ tab-երի, պահպանելով ճիշտ նույն ինտերֆեյսը։

### Տարբերակ 1. Մեկ կտտոցով Desktop Ծրագիր (`start_desktop.bat`)
1. Կրկնակի սեղմիր **`start_desktop.bat`**-ի վրա։
2. Ծրագիրը ավտոմատ կստուգի գրադարանները և անմիջապես կբացի Հսկիչի առանձին **Desktop պատուհանը (Soft)**։

### Տարբերակ 2. Launcher-ի միջոցով (`start.bat` կամ `launcher.py`)
1. Գործարկիր **`start.bat`** կամ **`launcher.py`**։
2. Սեղմիր **Run Desktop App** կոճակը — կբացվի ծրագրի պատուհանը։
3. (Եթե երբևէ ցանկանաս բացել բրաուզերով, կարող ես սեղմել **Browser** կոճակը)։

### Տարբերակ 3. Ինքնուրույն .EXE ֆայլի ստեղծում (`build_exe.bat`)
1. Կրկնակի սեղմիր **`build_exe.bat`**։
2. Արդյունքում `dist\Hskich\` թղթապանակում կստեղծվի պատրաստի **`Hskich.exe`** ֆայլը, որը կարող ես դնել Desktop-ին և բացել ինչպես ցանկացած Windows ծրագիր։

**Ամբողջական արդյունքների համար** (firewall, Security log, update history)
աջ սեղմիր .bat ֆայլի վրա → **Run as administrator**։

**Կարևոր՝** ամբողջական արդյունքների համար (firewall status, Security log,
hotfix history) launcher.py-ն գործարկեք **որպես Administrator** (աջ սեղմեք
python.exe կամ .py ֆայլի վրա → Run as Administrator), հակառակ դեպքում
dashboard-ը այդ կետերի փոխարեն ցուցադրում է "info" հաղորդագրություն։

### Այլընտրանք՝ հրամանի տողով

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### Ուզու՞մ ես մեկ .exe ֆայլ՝ առանց Python-ի տեղադրման

Windows-ի մեքենայի վրա (ոչ այստեղ, քանի որ սա Linux միջավայր է) կարող ես
launcher.py-ն վերածել ինքնուրույն .exe-ի.

```powershell
pip install pyinstaller
pyinstaller --onefile --windowed --name Hskich launcher.py
```

Սա կստեղծի `dist\Hskich.exe`, բայց ուշադրություն՝ դեռ պետք է `app.py`,
`scanner/`, `templates/`, `static/` և `requirements.txt` ֆայլերը մնան նույն
պանակում, քանի որ launcher-ը դրանք գործարկում է որպես առանձին Python
պրոցես։

## Ինչպես է աշխատում

- `app.py` — Flask սերվեր, միացնում է բոլոր scanner module-ները և ցուցադրում dashboard-ը
- `scanner/network_scan.py` — պորտեր և firewall
- `scanner/system_scan.py` — UAC, RDP, SMBv1, updates, հաշիվներ, startup
- `scanner/defender_scan.py` — Windows Defender ինտեգրացիա
- `scanner/event_logs.py` — Windows Event Log ընթերցում
- `scanner/risk_engine.py` — findings-երի հավաքում ու priority-ով դասավորում

Ամեն ինչ աշխատում է **միայն locally** (127.0.0.1:5000)։ Ոչինչ չի ուղարկվում ինտերնետ։

## Սահմանափակումներ

- Սա system-hardening/audit գործիք է, ոչ թե full antivirus engine — malware-ի իրական detection-ի համար այն հենվում է Windows Defender-ի վրա։
- Որոշ ստուգումներ (օր.՝ Security event log, հին hotfix-ների ցանկը) պահանջում են Administrator իրավունքներ, հակառակ դեպքում dashboard-ը կցուցադրի "info" մակարդակի հաղորդագրություն այդ ստուգման փոխարեն։
- Startup ծրագրերի ցանկը informational է. գործիքը ինքնուրույն չի որոշում՝ որ ծրագիրն է վնասակար, այլ պարզապես ցույց է տալիս ամբողջ ցանկը վերանայման համար։
