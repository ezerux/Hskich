"""Windows Registry autorun scanner - the same idea as Sysinternals Autoruns, scoped
to the persistence locations malware abuses most: Run/RunOnce keys, the Winlogon
Shell/Userinit values, and AppInit_DLLs."""
import os
import re

from .risk_engine import finding
from .ps import run_ps_safe

RUN_KEYS = [
    (r"HKCU:\Software\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
    (r"HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
    (r"HKLM:\Software\Microsoft\Windows\CurrentVersion\Run", "HKLM Run"),
    (r"HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce"),
    (r"HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32-bit)"),
]

SUSPICIOUS_PATTERNS = [
    (re.compile(r"\\temp\\", re.I), "runs from a Temp folder"),
    (re.compile(r"appdata\\local\\temp", re.I), "runs from a Temp folder"),
    (re.compile(r"powershell(\.exe)?.{0,40}-enc(odedcommand)?\b", re.I), "uses an encoded/obfuscated PowerShell command"),
    (re.compile(r"-w(indowstyle)?\s+hidden", re.I), "runs with a hidden window"),
    (re.compile(r"\.(pdf|docx?|xlsx?|jpg|png|txt)\.exe\b", re.I), "has a double file extension, a common disguise trick"),
    (re.compile(r"\\downloads\\", re.I), "runs from the Downloads folder"),
    (re.compile(r"\\public\\", re.I), "runs from a shared/public folder"),
    (re.compile(r"mshta\.exe|wscript\.exe|cscript\.exe|regsvr32\.exe.*/i:http", re.I), "uses a living-off-the-land binary often abused by malware"),
]


def get_registry_values(path):
    cmd = (
        f"$k = Get-ItemProperty -Path '{path}' -ErrorAction SilentlyContinue; "
        "if ($k) { $k.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | "
        "Select-Object Name,Value | ConvertTo-Json }"
    )
    data, err = run_ps_safe(cmd)
    if err or data is None:
        return [], err
    return (data if isinstance(data, list) else [data]), None


def extract_exe_path(value):
    value = value.strip()
    if not value:
        return None
    if value.startswith('"'):
        end = value.find('"', 1)
        if end != -1:
            return value[1:end]
    m = re.search(r"^(.*?\.exe)\b", value, re.I)
    if m:
        return m.group(1).strip()
    return value.split(" ")[0]


def check_winlogon():
    data, err = run_ps_safe(
        r"Get-ItemProperty 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' "
        "| Select-Object Shell,Userinit | ConvertTo-Json"
    )
    if err or data is None:
        return []
    findings = []
    shell = str(data.get("Shell") or "").strip()
    userinit = str(data.get("Userinit") or "").strip().lower()
    if shell and shell.lower() != "explorer.exe":
        findings.append(finding(
            "system", "critical", "Winlogon Shell has been modified",
            f'The Shell registry value is "{shell}" instead of the default explorer.exe. '
            "This is a classic persistence technique that replaces or chains onto the user shell at every login.",
            "Open regedit at HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon and restore Shell to explorer.exe if you didn't set this yourself.",
        ))
    if userinit and not userinit.startswith(r"c:\windows\system32\userinit.exe"):
        findings.append(finding(
            "system", "critical", "Winlogon Userinit has been modified",
            f'The Userinit registry value is "{data.get("Userinit")}" instead of the default '
            "C:\\Windows\\system32\\userinit.exe,. Malware sometimes appends itself here to run at every logon.",
            "Open regedit at the same Winlogon key and remove anything appended after userinit.exe, if you didn't add it.",
        ))
    return findings


def check_appinit_dlls():
    data, err = run_ps_safe(
        r"Get-ItemProperty 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Windows' "
        "| Select-Object AppInit_DLLs,LoadAppInit_DLLs | ConvertTo-Json"
    )
    if err or data is None:
        return []
    dlls = str(data.get("AppInit_DLLs") or "").strip()
    load_flag = data.get("LoadAppInit_DLLs")
    if dlls and load_flag:
        return [finding(
            "system", "high", "AppInit_DLLs is configured",
            f'AppInit_DLLs = "{dlls}" and LoadAppInit_DLLs is enabled, so every process that loads user32.dll also loads this DLL.',
            "This mechanism is rarely used legitimately today and is a known DLL-injection technique. Verify the DLL is expected, or clear the value if not.",
        )]
    return []


def run():
    findings = []
    all_entries = []

    for hive_path, label in RUN_KEYS:
        entries, _err = get_registry_values(hive_path)
        for e in entries:
            name = e.get("Name")
            value = e.get("Value")
            if value in (None, ""):
                continue
            value_str = str(value)
            exe_path = extract_exe_path(value_str)
            exists = None
            if exe_path:
                try:
                    exists = os.path.exists(exe_path)
                except OSError:
                    exists = None
            reasons = [msg for pattern, msg in SUSPICIOUS_PATTERNS if pattern.search(value_str)]
            all_entries.append({
                "key": hive_path, "label": label, "name": name, "value": value_str,
                "exe_path": exe_path, "exists": exists, "reasons": reasons,
            })
            if reasons:
                findings.append(finding(
                    "system", "high", f"Suspicious autorun entry: {name}",
                    f"{label} \\ {name} = {value_str}  -  " + "; ".join(reasons) + ".",
                    "Open regedit, navigate to this key, and remove the entry if you don't recognize it.",
                    evidence=[hive_path],
                ))
            elif exists is False:
                findings.append(finding(
                    "system", "low", f"Autorun entry points to a missing file: {name}",
                    f"{label} \\ {name} = {value_str}, but the referenced file wasn't found on disk.",
                    "Usually harmless leftover from an uninstalled program, but worth a quick look if unfamiliar.",
                ))

    findings += check_winlogon()
    findings += check_appinit_dlls()
    return findings, {"autoruns": all_entries}
