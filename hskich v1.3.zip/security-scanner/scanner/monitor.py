"""Live system resource monitoring plus threshold alerting."""
import hashlib, time, os
import psutil
from .monitor_alerts import push, get_alerts

def sha256_quick(path, max_bytes=512*1024):
    """Hash only the first 512 KB - fast enough for live process listing."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            h.update(f.read(max_bytes))
        return h.hexdigest()[:16] + "…"
    except OSError:
        return None

def get_system_metrics():
    cpu_percent = psutil.cpu_percent(interval=0.2)
    per_core    = psutil.cpu_percent(interval=None, percpu=True)
    vm          = psutil.virtual_memory()
    sw          = psutil.swap_memory()

    disks = []
    for part in psutil.disk_partitions(all=False):
        if "cdrom" in part.opts or not part.fstype:
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except (PermissionError, OSError):
            continue
        try:
            io = psutil.disk_io_counters(perdisk=True)
            dev = part.device.replace("\\\\.\\","").replace(":","")
            dev_io = io.get(dev)
        except Exception:
            dev_io = None
        disks.append({
            "device": part.device, "mountpoint": part.mountpoint,
            "fstype": part.fstype,
            "total_gb": round(usage.total/(1024**3),1),
            "used_gb":  round(usage.used /(1024**3),1),
            "free_gb":  round(usage.free /(1024**3),1),
            "percent":  usage.percent,
            "read_mb":  round(dev_io.read_bytes/(1024**2),1)  if dev_io else None,
            "write_mb": round(dev_io.write_bytes/(1024**2),1) if dev_io else None,
        })

    net = psutil.net_io_counters()
    net_if = psutil.net_if_stats()
    interfaces = {
        iface: {"isup": st.isup, "speed": st.speed, "mtu": st.mtu}
        for iface, st in net_if.items()
    }

    metrics = {
        "cpu_percent":  cpu_percent,
        "cpu_per_core": per_core,
        "ram_percent":  vm.percent,
        "ram_used_gb":  round(vm.used/(1024**3),1),
        "ram_total_gb": round(vm.total/(1024**3),1),
        "ram_avail_gb": round(vm.available/(1024**3),1),
        "swap_percent": sw.percent,
        "swap_used_gb": round(sw.used/(1024**3),1),
        "swap_total_gb":round(sw.total/(1024**3),1),
        "disks":        disks,
        "net_sent_mb":  round(net.bytes_sent/(1024**2),1),
        "net_recv_mb":  round(net.bytes_recv/(1024**2),1),
        "net_pkts_sent":net.packets_sent,
        "net_pkts_recv":net.packets_recv,
        "interfaces":   interfaces,
    }
    push(cpu_percent, vm.percent, disks)
    metrics["alerts"] = get_alerts()
    return metrics

def get_processes(limit=40, sort_by="cpu"):
    procs = []
    for p in psutil.process_iter(["pid","name"]):
        try:
            p.cpu_percent(None)
            procs.append(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    time.sleep(0.3)
    results = []
    for p in procs:
        try:
            with p.oneshot():
                cpu  = p.cpu_percent(None)
                mi   = p.memory_info()
                mem  = round(mi.rss/(1024**2),1)
                exe  = None
                h    = None
                try:
                    exe = p.exe()
                    h   = sha256_quick(exe) if exe else None
                except (psutil.AccessDenied, OSError):
                    pass
                try: status = p.status()
                except: status = ""
                try: uname = p.username()
                except: uname = ""
                results.append({
                    "pid": p.pid, "name": p.name(),
                    "cpu_percent": round(cpu,1),
                    "memory_mb":   mem,
                    "exe":   exe or "",
                    "hash":  h or "",
                    "status": status,
                    "user":  uname,
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    key = "cpu_percent" if sort_by == "cpu" else "memory_mb"
    results.sort(key=lambda r: r[key], reverse=True)
    return results[:limit]
