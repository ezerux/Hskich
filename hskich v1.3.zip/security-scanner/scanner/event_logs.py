"""Pulls recent, security-relevant entries from the Windows Event Log."""
from .risk_engine import finding
from .ps import run_ps_safe

# Security-channel event IDs worth flagging.
FAILED_LOGON = 4625
USER_CREATED = 4720
ADDED_TO_ADMIN_GROUP = 4732
ACCOUNT_LOCKOUT = 4740


def get_recent_logs(max_events=100):
    """General log feed for the Logs tab: recent errors/warnings across System + Application."""
    cmd = (
        "Get-WinEvent -FilterHashtable @{LogName=('System','Application'); Level=1,2,3; "
        f"StartTime=(Get-Date).AddDays(-3)}} -MaxEvents {max_events} -ErrorAction SilentlyContinue "
        "| Select-Object TimeCreated,LevelDisplayName,LogName,ProviderName,Id,"
        "@{N='Message';E={$_.Message -replace \"\\s+\",' '}} | ConvertTo-Json -Depth 3"
    )
    data, err = run_ps_safe(cmd, timeout=45)
    if err or data is None:
        return [], err
    entries = data if isinstance(data, list) else [data]
    for e in entries:
        e["severity"] = classify_log_severity(e)
    return entries, None


# Event IDs that mean trouble regardless of the Windows "Level" label.
CRITICAL_EVENT_IDS = {41, 1001, 6008}  # unexpected reboot, BugCheck/BSOD, unexpected shutdown


def classify_log_severity(entry):
    """Map a raw Windows event log entry onto our critical/high/medium/low/info scale."""
    event_id = entry.get("Id")
    if event_id in CRITICAL_EVENT_IDS:
        return "critical"
    level = (entry.get("LevelDisplayName") or "").lower()
    if level == "critical":
        return "critical"
    if level == "error":
        return "high"
    if level == "warning":
        return "medium"
    return "info"


def check_security_events():
    cmd = (
        "Get-WinEvent -FilterHashtable @{LogName='Security'; "
        f"Id=({FAILED_LOGON},{USER_CREATED},{ADDED_TO_ADMIN_GROUP},{ACCOUNT_LOCKOUT}); "
        "StartTime=(Get-Date).AddDays(-7)} -MaxEvents 500 -ErrorAction SilentlyContinue "
        "| Group-Object Id | Select-Object Name,Count | ConvertTo-Json"
    )
    data, err = run_ps_safe(cmd, timeout=45)
    if err:
        return [finding(
            "logs", "info", "Could not read the Security event log",
            "Reading the Security log needs administrator rights.",
            "Re-run this tool as Administrator to include failed-logon and account-change monitoring.",
        )]
    if data is None:
        return []

    groups = data if isinstance(data, list) else [data]
    counts = {int(g["Name"]): g["Count"] for g in groups}
    findings = []

    failed = counts.get(FAILED_LOGON, 0)
    if failed > 20:
        findings.append(finding(
            "logs", "high", f"{failed} failed login attempts in the last 7 days",
            "A high volume of failed logons can indicate brute-force attempts or a misconfigured service.",
            "Review Security log event ID 4625 for source accounts/IPs, and consider an account lockout policy.",
        ))
    elif failed > 5:
        findings.append(finding(
            "logs", "medium", f"{failed} failed login attempts in the last 7 days",
            "Worth a look to confirm these are your own mistyped passwords rather than someone else's attempts.",
            "Review Security log event ID 4625 for the source of these attempts.",
        ))

    if counts.get(ADDED_TO_ADMIN_GROUP, 0) > 0:
        findings.append(finding(
            "logs", "high", f"{counts[ADDED_TO_ADMIN_GROUP]} account(s) were added to the Administrators group recently",
            "Unexpected privilege escalation is a common sign of compromise.",
            "Review Security log event ID 4732 to confirm you made these changes.",
        ))

    if counts.get(ACCOUNT_LOCKOUT, 0) > 3:
        findings.append(finding(
            "logs", "medium", f"{counts[ACCOUNT_LOCKOUT]} account lockouts in the last 7 days",
            "Repeated lockouts often accompany brute-force login attempts.",
            "Review Security log event ID 4740 for the affected accounts.",
        ))

    return findings


def run():
    findings = check_security_events()
    recent, err = get_recent_logs()
    extra = {"recent_logs": recent}
    if err:
        extra["recent_logs_error"] = err
    return findings, extra
