"""Reads Windows Defender status and can trigger a scan.
This deliberately relies on the built-in, always-updated Defender engine rather than
shipping a custom malware scanner - signature databases go stale in days, and
Defender already runs with system-level access this tool doesn't need."""
import subprocess

from .risk_engine import finding
from .ps import run_ps_safe


def check_status():
    data, err = run_ps_safe(
        "Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,"
        "AntispywareEnabled,AntivirusSignatureAge,QuickScanAge,FullScanAge | ConvertTo-Json"
    )
    if err or data is None:
        return [finding(
            "malware", "info", "Could not read Windows Defender status",
            err or "No data returned - Defender may be replaced by third-party antivirus, which is fine if it's active.",
            "If you use third-party antivirus, confirm it's enabled and up to date in its own dashboard.",
        )], {}

    findings = []
    if not data.get("AntivirusEnabled", True):
        findings.append(finding(
            "malware", "critical", "Antivirus protection is disabled",
            "No active malware scanning is protecting this machine.",
            "Enable antivirus protection in Windows Security > Virus & threat protection.",
            reference="https://learn.microsoft.com/en-us/defender-endpoint/microsoft-defender-antivirus-windows",
        ))
    if not data.get("RealTimeProtectionEnabled", True):
        findings.append(finding(
            "malware", "critical", "Real-time protection is disabled",
            "New files and running processes are not being scanned as they execute.",
            "Enable real-time protection in Windows Security > Virus & threat protection > Manage settings.",
            reference="https://learn.microsoft.com/en-us/defender-endpoint/microsoft-defender-antivirus-windows",
        ))
    sig_age = data.get("AntivirusSignatureAge")
    if isinstance(sig_age, int) and sig_age > 7:
        findings.append(finding(
            "malware", "high", "Antivirus signatures are outdated",
            f"Signatures were last updated {sig_age} days ago, so recent malware may go undetected.",
            "Update signatures in Windows Security > Virus & threat protection > Check for updates.",
        ))
    quick_age = data.get("QuickScanAge")
    if isinstance(quick_age, int) and quick_age > 14:
        findings.append(finding(
            "malware", "medium", "No recent malware scan has been run",
            f"The last quick scan was {quick_age} days ago.",
            "Run a scan from this dashboard, or open Windows Security > Virus & threat protection > Quick scan.",
        ))
    return findings, data


def trigger_quick_scan():
    """Fire-and-forget: start a background quick scan via Defender. Returns immediately."""
    try:
        from .ps import SUBPROCESS_FLAGS
        subprocess.Popen(
            ["powershell", "-WindowStyle", "Hidden", "-NoProfile", "-NonInteractive", "-Command", "Start-MpScan -ScanType QuickScan"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            **SUBPROCESS_FLAGS,
        )
        return True, None
    except (FileNotFoundError, OSError) as exc:
        return False, str(exc)


def run():
    findings, status = check_status()
    return findings, {"defender_status": status}
