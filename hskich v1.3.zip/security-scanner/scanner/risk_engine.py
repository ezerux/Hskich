"""Turns raw findings from each scanner module into a prioritized, sorted list."""

SEVERITY_WEIGHT = {
    "critical": 4,
    "high": 3,
    "medium": 2,
    "low": 1,
    "info": 0,
}


def finding(category, severity, title, detail, recommendation, evidence=None, reference=None):
    """Build one normalized finding dict."""
    severity = severity if severity in SEVERITY_WEIGHT else "info"
    return {
        "category": category,
        "severity": severity,
        "title": title,
        "detail": detail,
        "recommendation": recommendation,
        "evidence": evidence or [],
        "reference": reference,
    }


def aggregate(all_findings):
    """Sort findings by severity (critical first) and compute summary counts."""
    ordered = sorted(all_findings, key=lambda f: SEVERITY_WEIGHT.get(f["severity"], 0), reverse=True)
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in ordered:
        counts[f["severity"]] += 1
    return {
        "findings": ordered,
        "counts": counts,
        "total": len(ordered),
    }
