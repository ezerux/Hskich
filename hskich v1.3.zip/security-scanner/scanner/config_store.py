"""Tiny local JSON config file - currently holds the optional MalwareBazaar
Auth-Key and any custom folders the user wants the file watcher to cover."""
import json
import os

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "hskich_config.json")


def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_config(updates):
    current = load_config()
    current.update(updates)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(current, f, indent=2)
    return current


def get_malwarebazaar_key():
    return load_config().get("malwarebazaar_auth_key", "")


def get_clamav_db_path():
    return load_config().get("clamav_db_path", "")


def get_watch_paths():
    return load_config().get("watch_paths")  # None = use defaults
