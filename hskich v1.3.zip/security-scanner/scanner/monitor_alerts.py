"""Threshold-based alerting for monitoring metrics.
Tracks a rolling window of readings and fires when thresholds are exceeded."""
from collections import deque
import time

THRESHOLDS = {
    "cpu_percent":  {"warn": 75, "critical": 90, "label": "CPU usage"},
    "ram_percent":  {"warn": 80, "critical": 95, "label": "RAM usage"},
    "disk_percent": {"warn": 85, "critical": 95, "label": "Disk usage"},
}
WINDOW_SIZE = 10   # readings
MIN_FIRES   = 7    # out of 10 readings must exceed threshold

_history = {k: deque(maxlen=WINDOW_SIZE) for k in THRESHOLDS}
_disk_history = {}   # mountpoint -> deque

def push(cpu, ram, disks):
    _history["cpu_percent"].append(cpu)
    _history["ram_percent"].append(ram)
    for d in disks:
        mp = d["mountpoint"]
        if mp not in _disk_history:
            _disk_history[mp] = deque(maxlen=WINDOW_SIZE)
        _disk_history[mp].append(d["percent"])

def get_alerts():
    alerts = []
    for key, cfg in THRESHOLDS.items():
        if key == "disk_percent":
            continue
        hist = list(_history[key])
        if len(hist) < 3:
            continue
        crit_count = sum(1 for v in hist if v >= cfg["critical"])
        warn_count = sum(1 for v in hist if v >= cfg["warn"])
        if crit_count >= MIN_FIRES:
            alerts.append({"level":"critical","metric":cfg["label"],"value":hist[-1],"threshold":cfg["critical"]})
        elif warn_count >= MIN_FIRES:
            alerts.append({"level":"warning","metric":cfg["label"],"value":hist[-1],"threshold":cfg["warn"]})

    for mp, hist in _disk_history.items():
        vals = list(hist)
        if not vals: continue
        v = vals[-1]
        cfg = THRESHOLDS["disk_percent"]
        if v >= cfg["critical"]:
            alerts.append({"level":"critical","metric":f"Disk {mp}","value":v,"threshold":cfg["critical"]})
        elif v >= cfg["warn"]:
            alerts.append({"level":"warning","metric":f"Disk {mp}","value":v,"threshold":cfg["warn"]})

    return alerts
