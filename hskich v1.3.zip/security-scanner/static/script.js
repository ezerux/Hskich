'use strict';
// ═══════════════════════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════════════════════
const navItems = document.querySelectorAll('.nav-item');
let monitorTimer = null, processSort = 'cpu', lastFindings = [], lastScanMeta = null;
let allLogEntries = [];

function switchView(target, push = true) {
  navItems.forEach(n => n.classList.toggle('active', n.dataset.view === target));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('hidden', v.id !== `view-${target}`));
  if (target === 'logs')      loadLogs();
  if (target === 'malware')   { loadClamavStatus(); loadDefenderStatus(); }
  if (target === 'monitor')   startMonitorPolling();
  else                        stopMonitorPolling();
  if (target === 'filewatch') loadWatchEvents();
  if (target === 'network')   { loadPorts(); loadConnections(); }
  if (target === 'registry')  scanRegistry();
  if (push) {
    const u = new URL(location); u.searchParams.set('view', target); history.replaceState({}, '', u);
  }
}

navItems.forEach(ni => {
  ni.querySelector('.nav-label').addEventListener('click', () => switchView(ni.dataset.view));
  ni.querySelector('.nav-popout')?.addEventListener('click', e => {
    e.stopPropagation();
    const u = new URL(location.origin + location.pathname);
    u.searchParams.set('view', ni.dataset.view); window.open(u, '_blank');
  });
});

// ═══════════════════════════════════════════════════════════
//  TAB BARS
// ═══════════════════════════════════════════════════════════
document.querySelectorAll('.tab-bar').forEach(bar => {
  bar.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.closest('.view');
      parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const pane = document.getElementById(`tab-${btn.dataset.tab}`);
      if (pane) pane.classList.add('active');
    });
  });
});

// ═══════════════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════════════
const SEV_LABEL = {critical:'Critical',high:'High',medium:'Medium',low:'Low',info:'Info'};
const CAT_LABEL = {network:'Network',system:'System',malware:'Malware',logs:'Logs'};

function esc(s) {
  const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML;
}
function fmtDate(raw) {
  if (!raw) return '';
  if (typeof raw === 'string' && raw.startsWith('/Date(')) {
    const ms = parseInt(raw.replace('/Date(','').split('+')[0].split(')')[0], 10);
    return new Date(ms).toLocaleString();
  }
  return raw;
}
function sevTag(sev) { return `<span class="sev-tag ${sev}">${SEV_LABEL[sev]||sev}</span>`; }

// ═══════════════════════════════════════════════════════════
//  OVERVIEW / FINDINGS
// ═══════════════════════════════════════════════════════════
let activeFilter = 'all', activeCat = 'all';

document.querySelectorAll('.chip[data-filter]').forEach(c => {
  c.addEventListener('click', () => {
    document.querySelectorAll('.chip[data-filter]').forEach(x => x.classList.remove('active'));
    c.classList.add('active'); activeFilter = c.dataset.filter; renderFindingsList();
  });
});
document.querySelectorAll('.hero-count').forEach(hc => {
  hc.addEventListener('click', () => {
    document.querySelectorAll('.chip[data-filter]').forEach(x => x.classList.toggle('active', x.dataset.filter === hc.dataset.filter));
    activeFilter = hc.dataset.filter; renderFindingsList();
    switchView('overview');
  });
});
document.getElementById('filter-category').addEventListener('change', e => {
  activeCat = e.target.value; renderFindingsList();
});

function renderCounts(counts) {
  ['critical','high','medium','low','info'].forEach(s => {
    document.getElementById(`count-${s}`).textContent = counts[s] ?? 0;
  });
}

function renderNavBadges(findings) {
  const total = findings.length;
  document.getElementById('badge-overview').textContent = total || '';
  const cats = {network:0,system:0,malware:0,logs:0};
  findings.forEach(f => {
    if (cats[f.category] !== undefined && (f.severity==='critical'||f.severity==='high'))
      cats[f.category]++;
  });
  Object.entries(cats).forEach(([cat,n]) => {
    const el = document.getElementById(`badge-${cat}`);
    if (!el) return;
    el.textContent = n || ''; el.classList.toggle('hot', n > 0);
  });
}

function renderFindingsList() {
  const list = document.getElementById('findings-list');
  let items = lastFindings;
  if (activeFilter !== 'all') items = items.filter(f => f.severity === activeFilter);
  if (activeCat   !== 'all') items = items.filter(f => f.category === activeCat);
  if (!items.length) { list.innerHTML = '<p class="empty-state">No findings for this filter.</p>'; return; }
  list.innerHTML = items.map(f => `
    <div class="finding ${f.severity}">
      <div class="finding-top">
        ${sevTag(f.severity)}
        <span class="finding-title">${esc(f.title)}</span>
        <span class="finding-cat">${CAT_LABEL[f.category]||f.category}</span>
      </div>
      <div class="finding-detail">${esc(f.detail)}</div>
      <div class="finding-rec">${esc(f.recommendation)}</div>
      ${f.reference?`<a class="finding-ref" href="${esc(f.reference)}" target="_blank" rel="noopener">Learn more &rarr;</a>`:''}
    </div>`).join('');
}

function renderFindings(findings) {
  lastFindings = findings;
  renderNavBadges(findings);
  renderFindingsList();
}

// ═══════════════════════════════════════════════════════════
//  FULL SCAN
// ═══════════════════════════════════════════════════════════
document.getElementById('run-scan').addEventListener('click', async () => {
  const btn = document.getElementById('run-scan');
  btn.disabled = true; btn.textContent = 'Scanning…';
  document.getElementById('scan-meta').textContent = 'Scan in progress…';
  try {
    const data = await fetch('/api/scan', {method:'POST'}).then(r => r.json());
    renderCounts(data.counts||{});
    renderFindings(data.findings||[]);
    // populate sub-views from cached scan data
    const d = data.details||{};
    renderPorts(d.network_scan?.listening_ports);
    renderSystemDetails(d.system_scan);
    renderDefenderBox(d.defender_scan?.defender_status);
    renderClamavBox(d.clamav_scan?.clamav);
    const when = data.ran_at ? new Date(data.ran_at).toLocaleString() : '';
    lastScanMeta = {when, total:data.total, isAdmin:data.is_admin, counts:data.counts};
    document.getElementById('scan-meta').textContent =
      `Last scan: ${when} · ${data.total} finding(s) · ${data.is_admin?'Administrator':'Non-administrator'}`;
  } catch (e) {
    document.getElementById('scan-meta').textContent = 'Scan error — is app.py running?';
  } finally {
    btn.disabled = false; btn.textContent = '▶ Run full scan';
  }
});

// ═══════════════════════════════════════════════════════════
//  NETWORK
// ═══════════════════════════════════════════════════════════
const RISKY_PORTS = new Set([21,23,135,139,445,1433,3306,3389,5900]);

async function loadPorts() {
  const scan = await fetch('/api/scan').then(r=>r.json()).catch(()=>null);
  const ports = scan?.details?.network_scan?.listening_ports || [];
  renderPorts(ports);
}
function renderPorts(ports=[]) {
  const tb = document.querySelector('#ports-table tbody');
  tb.innerHTML = ports.map(p => {
    const risk = RISKY_PORTS.has(p.port);
    return `<tr class="${risk?'tr-high':''}">
      <td>${p.port}</td><td>${esc(p.address)}</td><td>${esc(p.process)}</td><td>${p.pid??''}</td>
      <td>${risk?`<span class="sev-tag high">High</span>`:''}</td></tr>`;
  }).join('') || '<tr><td colspan="5" class="note">No data — run a full scan first.</td></tr>';
}

let allConns = [];
async function loadConnections() {
  const data = await fetch('/api/network/connections').then(r=>r.json()).catch(()=>({connections:[],error:''}));
  allConns = data.connections||[];
  renderConnections();
}
function renderConnections() {
  const extOnly = document.getElementById('ext-only')?.checked;
  const rows = extOnly ? allConns.filter(c=>c.is_external) : allConns;
  const tb = document.querySelector('#conns-table tbody');
  tb.innerHTML = rows.map(c => `
    <tr class="${c.alert?'tr-critical':''}">
      <td>${esc(c.process)}</td><td>${esc(c.local_addr)}</td>
      <td>${esc(c.remote_ip)}</td><td>${c.remote_port}</td>
      <td>${esc(c.hostname)}</td><td>${esc(c.status)}</td>
      <td>${c.alert?`<span class="sev-tag critical">${esc(c.alert)}</span>`:''}</td>
    </tr>`).join('')||'<tr><td colspan="7" class="note">No active outbound connections.</td></tr>';
}
document.getElementById('ext-only')?.addEventListener('change', renderConnections);
document.getElementById('refresh-conns')?.addEventListener('click', loadConnections);
document.getElementById('refresh-ports')?.addEventListener('click', loadPorts);
document.getElementById('refresh-fw')?.addEventListener('click', async () => {
  const data = await fetch('/api/network/firewall').then(r=>r.json()).catch(()=>({rules:[]}));
  const tb = document.querySelector('#fw-table tbody');
  tb.innerHTML = (data.rules||[]).map(r =>
    `<tr><td>${esc(r.name)}</td><td>${esc(r.action)}</td><td>${esc(r.profile)}</td></tr>`
  ).join('')||'<tr><td colspan="3" class="note">No rules / need Administrator.</td></tr>';
});
document.getElementById('refresh-netio')?.addEventListener('click', async () => {
  const data = await fetch('/api/network/perprocess').then(r=>r.json()).catch(()=>({io:[]}));
  const tb = document.querySelector('#netio-table tbody');
  tb.innerHTML = (data.io||[]).map(p =>
    `<tr><td>${esc(p.name)}</td><td>${p.pid}</td><td>${p.read_mb}</td><td>${p.write_mb}</td></tr>`
  ).join('')||'<tr><td colspan="4" class="note">No data.</td></tr>';
});

// ═══════════════════════════════════════════════════════════
//  SYSTEM
// ═══════════════════════════════════════════════════════════
function renderSystemDetails(sys) {
  const tb = document.querySelector('#startup-table tbody');
  if (tb && sys?.startup_items) {
    tb.innerHTML = sys.startup_items.map(i=>
      `<tr><td>${esc(i.name)}</td><td>${esc(i.command)}</td><td>${esc(i.location)}</td></tr>`
    ).join('')||'<tr><td colspan="3" class="note">No data</td></tr>';
  }
  const al = document.getElementById('admins-list');
  if (al && sys?.local_admins) {
    al.innerHTML = sys.local_admins.map(a=>`<li>${esc(a)}</li>`).join('')||'<li class="note">No data</li>';
  }
}

// ═══════════════════════════════════════════════════════════
//  MALWARE — DEFENDER
// ═══════════════════════════════════════════════════════════
async function loadDefenderStatus() {
  const scan = await fetch('/api/scan').then(r=>r.json()).catch(()=>null);
  renderDefenderBox(scan?.details?.defender_scan?.defender_status);
}
function renderDefenderBox(status) {
  const el = document.getElementById('defender-status');
  el.textContent = (status && Object.keys(status).length)
    ? JSON.stringify(status, null, 2)
    : 'No Defender data (may need Administrator rights).';
}
document.getElementById('run-defender-scan').addEventListener('click', async () => {
  const btn = document.getElementById('run-defender-scan');
  btn.disabled = true;
  const d = await fetch('/api/defender/scan',{method:'POST'}).then(r=>r.json()).catch(()=>({error:'failed'}));
  document.getElementById('defender-scan-note').textContent = d.note||d.error||'';
  btn.disabled = false;
});

// ═══════════════════════════════════════════════════════════
//  MALWARE — CLAMAV
// ═══════════════════════════════════════════════════════════
async function loadClamavStatus() {
  const d = await fetch('/api/clamav/status').then(r=>r.json()).catch(()=>null);
  renderClamavBox(d);
  const dbInput = document.getElementById('clamav-db-input');
  if (dbInput && !dbInput.value) {
    dbInput.value = d?.db_path || '';
  }
}
function renderClamavBox(d) {
  const box = document.getElementById('clamav-status');
  const pill = document.getElementById('clamav-installed-pill');
  if (!d?.installed) {
    pill.textContent='Not installed'; pill.className='pill warn-pill';
    box.textContent='ClamAV not found. Download: https://www.clamav.net/download'; return;
  }
  pill.textContent='Installed'; pill.className='pill ok-pill';
  const dbInfo = d.db_path ? `DB folder: ${d.db_path}\n` : '';
  const age = d.db_age_days == null ? 'Database age unknown (needs first update).'
    : `Database age: ${d.db_age_days} day(s) (${d.db_file||''})`;
  box.textContent = `clamscan: ${d.clamscan}\nfreshclam: ${d.freshclam}\n${dbInfo}${age}`;
}
async function runClamavScan(targets = null, label = 'ClamAV scan') {
  const btn = document.getElementById('clamav-scan-btn');
  const customBtn = document.getElementById('clamav-custom-scan-btn');
  const note = document.getElementById('clamav-note');
  const res = document.getElementById('clamav-results');
  if (btn) btn.disabled = true;
  if (customBtn) customBtn.disabled = true;
  note.textContent = `${label} in progress…`;
  res.innerHTML = '';
  const payload = targets ? {paths: targets} : {};
  const d = await fetch('/api/clamav/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(r=>r.json()).catch(()=>({error:'failed'}));
  if (d.error) { note.textContent=d.error; if (btn) btn.disabled=false; if (customBtn) customBtn.disabled=false; return; }
  note.textContent=`Scanned: ${(d.scanned||[]).join(', ')}`;
  const list = d.infected || [];
  res.innerHTML = list.length
    ? `<div class="finding critical"><div class="finding-top">${sevTag('critical')}
        <span class="finding-title">${list.length} infected file(s)</span></div>
        <ul>${list.map(i=>`<li><strong>${esc(i.file)}</strong> — ${esc(i.signature)}</li>`).join('')}</ul>
        <div class="finding-rec">Quarantine or delete these files immediately.</div></div>`
    : '<p class="empty-state">No infected files found.</p>';
  if (btn) btn.disabled=false;
  if (customBtn) customBtn.disabled=false;
  return d;
}
document.getElementById('clamav-update-btn').addEventListener('click', async () => {
  const btn = document.getElementById('clamav-update-btn'); btn.disabled=true;
  const d = await fetch('/api/clamav/update',{method:'POST'}).then(r=>r.json()).catch(()=>({error:'failed'}));
  document.getElementById('clamav-note').textContent = d.note||d.error||'';
  btn.disabled=false;
});
document.getElementById('clamav-scan-btn').addEventListener('click', async () => {
  await runClamavScan(null, 'Scanning default folders');
});
document.getElementById('clamav-custom-scan-btn').addEventListener('click', async () => {
  const path = document.getElementById('clamav-path-input').value.trim();
  if (!path) {
    document.getElementById('clamav-note').textContent = 'Enter a file or folder path to scan.';
    return;
  }
  await runClamavScan([path], `Scanning custom path: ${path}`);
});
document.getElementById('clamav-db-save-btn').addEventListener('click', async () => {
  const path = document.getElementById('clamav-db-input').value.trim();
  await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({clamav_db_path:path})});
  document.getElementById('clamav-note').textContent = path ? `Saved ClamAV DB path: ${path}` : 'Cleared ClamAV DB path.';
});

// ═══════════════════════════════════════════════════════════
//  MALWARE — HASH / PROCESS INTEGRITY
// ═══════════════════════════════════════════════════════════
document.getElementById('mb-key-save').addEventListener('click', async () => {
  const key = document.getElementById('mb-key-input').value.trim();
  await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({malwarebazaar_auth_key:key})});
  document.getElementById('hash-note').textContent = 'Key saved.';
});
document.getElementById('run-hash-check').addEventListener('click', async () => {
  const btn = document.getElementById('run-hash-check'); btn.disabled=true;
  document.getElementById('hash-note').textContent='Hashing processes…';
  const d = await fetch('/api/hash/check',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({limit:20})}).then(r=>r.json()).catch(()=>({results:[]}));
  const tb = document.querySelector('#hash-table tbody');
  tb.innerHTML=(d.results||[]).map(r=>{
    const status = r.malware?`<span class="sev-tag critical">MALWARE</span>`:
                   r.clean?'<span class="sev-tag low">Clean</span>':
                   '<span class="sev-tag info">Unknown</span>';
    return `<tr class="${r.malware?'tr-critical':''}">
      <td>${esc(r.name)}</td><td>${r.pid}</td>
      <td class="mono" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(r.path)}">${esc(r.path)}</td>
      <td class="mono">${esc(r.sha256||'')}</td><td>${status}</td></tr>`;
  }).join('')||'<tr><td colspan="5" class="note">No data</td></tr>';
  document.getElementById('hash-note').textContent = d.has_key?'':
    'No MalwareBazaar key — hashes computed but not checked online.';
  btn.disabled=false;
});

// ═══════════════════════════════════════════════════════════
//  REGISTRY
// ═══════════════════════════════════════════════════════════
async function scanRegistry() {
  document.getElementById('registry-note').textContent='Scanning…';
  const d = await fetch('/api/registry/scan').then(r=>r.json()).catch(()=>({findings:[],autoruns:[]}));
  const fbox = document.getElementById('registry-findings');
  fbox.innerHTML = (d.findings||[]).map(f=>`
    <div class="finding ${f.severity}">
      <div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
      <div class="finding-detail">${esc(f.detail)}</div>
      <div class="finding-rec">${esc(f.recommendation)}</div>
    </div>`).join('')||'<p class="empty-state">No suspicious autorun entries found.</p>';
  const tb = document.querySelector('#registry-table tbody');
  tb.innerHTML=(d.autoruns||[]).map(a=>`
    <tr class="${a.reasons?.length?'tr-high':''}">
      <td class="mono" style="font-size:11px">${esc(a.label)}</td>
      <td>${esc(a.name)}</td>
      <td class="mono" style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.value)}">${esc(a.value)}</td>
      <td>${a.exists===true?'<span class="tick-yes">✓</span>':a.exists===false?'<span class="tick-no">✗ Missing</span>':'–'}</td>
      <td>${a.reasons?.length?`<span class="sev-tag high">${esc(a.reasons[0])}</span>`:''}</td>
    </tr>`).join('')||'<tr><td colspan="5" class="note">No autorun entries found.</td></tr>';
  document.getElementById('registry-note').textContent=`${(d.autoruns||[]).length} entries found.`;
}
document.getElementById('refresh-registry').addEventListener('click', scanRegistry);

// ═══════════════════════════════════════════════════════════
//  FILE SCANNER
// ═══════════════════════════════════════════════════════════
const HOME = '%USERPROFILE%';
const PRESET_PATHS = {
  temp:      `${HOME}\\AppData\\Local\\Temp`,
  downloads: `${HOME}\\Downloads`,
  startup:   `${HOME}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup`,
};
['temp','downloads','startup'].forEach(k => {
  document.getElementById(`filescan-${k}`).addEventListener('click', () => {
    document.getElementById('filescan-path').value = PRESET_PATHS[k];
  });
});
document.getElementById('run-filescan').addEventListener('click', async () => {
  const folder = document.getElementById('filescan-path').value.trim();
  if (!folder) { document.getElementById('filescan-note').textContent='Enter a folder path.'; return; }
  const btn = document.getElementById('run-filescan'); btn.disabled=true;
  document.getElementById('filescan-note').textContent='Scanning…';
  const d = await fetch('/api/filescan',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({folder})}).then(r=>r.json()).catch(e=>({error:String(e)}));
  if (d.error) { document.getElementById('filescan-note').textContent=d.error; btn.disabled=false; return; }
  const fbox = document.getElementById('filescan-findings');
  const allF = [...(d.findings||[])];
  if (d.clamav_infected?.length) {
    d.clamav_infected.forEach(i=>allF.push({severity:'critical',title:`ClamAV: ${i.signature}`,detail:i.file,recommendation:'Quarantine or delete this file immediately.'}));
  }
  fbox.innerHTML=allF.map(f=>`
    <div class="finding ${f.severity}">
      <div class="finding-top">${sevTag(f.severity)}<span class="finding-title">${esc(f.title)}</span></div>
      <div class="finding-detail">${esc(f.detail)}</div>
      <div class="finding-rec">${esc(f.recommendation)}</div>
    </div>`).join('')||'<p class="empty-state">No suspicious files found.</p>';
  document.getElementById('filescan-count').textContent=`(${d.total_files} files checked)`;
  const tb=document.querySelector('#filescan-table tbody');
  const suspicious=(d.files||[]).filter(f=>f.flags?.length);
  tb.innerHTML=suspicious.map(f=>`
    <tr class="${f.flags?.length?'tr-high':''}">
      <td class="mono" style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(f.path)}">${esc(f.name)}</td>
      <td>${Math.round(f.size/1024)} KB</td>
      <td>${(f.flags||[]).map(flag=>`<span class="sev-tag high" style="margin-right:3px">${esc(flag)}</span>`).join('')}</td>
    </tr>`).join('')||'<tr><td colspan="3" class="note">No flagged files.</td></tr>';
  document.getElementById('filescan-note').textContent=`Done. ${allF.length} issue(s).`;
  btn.disabled=false;
});

// ═══════════════════════════════════════════════════════════
//  EVENT LOGS (with severity coloring)
// ═══════════════════════════════════════════════════════════
async function loadLogs() {
  const note=document.getElementById('logs-note'); note.textContent='Loading…';
  const d = await fetch('/api/logs').then(r=>r.json()).catch(()=>({entries:[],error:'failed'}));
  allLogEntries=d.entries||[];
  renderLogs();
  note.textContent=d.error||`${allLogEntries.length} entries`;
}
function logSeverity(level) {
  if (!level) return 'info';
  const l=level.toLowerCase();
  if (l.includes('critical')) return 'critical';
  if (l.includes('error'))    return 'high';
  if (l.includes('warning'))  return 'medium';
  return 'info';
}
function renderLogs() {
  const levelF=document.getElementById('logs-filter-level').value;
  const textF =document.getElementById('logs-filter-text').value.toLowerCase();
  const tb=document.querySelector('#logs-table tbody');
  const rows=allLogEntries.filter(e=>{
    if (levelF!=='all' && e.LevelDisplayName!==levelF) return false;
    if (textF && !(e.ProviderName||'').toLowerCase().includes(textF)
              && !(e.Message||'').toLowerCase().includes(textF)) return false;
    return true;
  });
  tb.innerHTML=rows.map(e=>{
    const sev=logSeverity(e.LevelDisplayName);
    const rowCls=sev==='critical'?'tr-critical':sev==='high'?'tr-high':'';
    const tag=sev!=='info'?sevTag(sev):'';
    return `<tr class="${rowCls}">
      <td>${esc(fmtDate(e.TimeCreated))}</td>
      <td>${tag} ${esc(e.LevelDisplayName||'')}</td>
      <td>${esc(e.LogName||'')}</td>
      <td>${esc(e.ProviderName||'')}</td>
      <td title="${esc(e.Message||'')}">${esc(e.Message||'')}</td>
    </tr>`;
  }).join('')||'<tr><td colspan="5" class="note">No entries (or Administrator required)</td></tr>';
}
document.getElementById('refresh-logs').addEventListener('click', loadLogs);
document.getElementById('logs-filter-level').addEventListener('change', renderLogs);
document.getElementById('logs-filter-text').addEventListener('input', renderLogs);

// ═══════════════════════════════════════════════════════════
//  MONITORING
// ═══════════════════════════════════════════════════════════
const MAX_H=50; let cpuH=[], ramH=[];

function drawChart(canvas, data, color) {
  if (!canvas) return;
  const ctx=canvas.getContext('2d');
  const W=canvas.clientWidth||260, H=canvas.clientHeight||48;
  canvas.width=W; canvas.height=H;
  ctx.clearRect(0,0,W,H);
  if (data.length<2) return;
  ctx.strokeStyle=color; ctx.lineWidth=1.5; ctx.beginPath();
  data.forEach((v,i)=>{
    const x=(i/(MAX_H-1))*W, y=H-(Math.min(v,100)/100)*H;
    i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
  });
  ctx.stroke();
  // fill
  const grad=ctx.createLinearGradient(0,0,0,H);
  grad.addColorStop(0, color+'40'); grad.addColorStop(1, color+'00');
  ctx.fillStyle=grad;
  ctx.lineTo(W,H); ctx.lineTo(0,H); ctx.closePath(); ctx.fill();
}

function renderMonitorAlerts(alerts) {
  const bar=document.getElementById('monitor-alerts-bar');
  bar.innerHTML=(alerts||[]).map(a=>`
    <div class="alert-banner ${a.level==='warning'?'warn':''}">
      <span class="sev-tag ${a.level==='critical'?'critical':'medium'}">${a.level.toUpperCase()}</span>
      <strong>${esc(a.metric)}</strong> is at ${a.value.toFixed(0)}% (threshold: ${a.threshold}%)
    </div>`).join('');
  const mcCpu=document.getElementById('mc-cpu');
  const mcRam=document.getElementById('mc-ram');
  if (alerts?.some(a=>a.metric.includes('CPU'))) mcCpu?.classList.add('mc-alert'); else mcCpu?.classList.remove('mc-alert');
  if (alerts?.some(a=>a.metric.includes('RAM'))) mcRam?.classList.add('mc-alert'); else mcRam?.classList.remove('mc-alert');
}

async function pollSystemMetrics() {
  const d=await fetch('/api/monitor/system').then(r=>r.json()).catch(()=>null);
  if (!d||d.error) return;
  document.getElementById('metric-cpu').textContent=`${d.cpu_percent.toFixed(0)}%`;
  document.getElementById('metric-ram').textContent=`${d.ram_percent.toFixed(0)}%`;
  document.getElementById('metric-ram').title=`${d.ram_used_gb} / ${d.ram_total_gb} GB`;
  document.getElementById('metric-swap').textContent=
    `Used: ${d.swap_used_gb} / ${d.swap_total_gb} GB (${d.swap_percent.toFixed(0)}%)`;
  document.getElementById('metric-net').textContent=
    `\u2191 ${d.net_sent_mb} MB sent\n\u2193 ${d.net_recv_mb} MB received\nPackets: ${d.net_pkts_sent} / ${d.net_pkts_recv}`;
  cpuH.push(d.cpu_percent); ramH.push(d.ram_percent);
  if (cpuH.length>MAX_H) cpuH.shift();
  if (ramH.length>MAX_H) ramH.shift();
  drawChart(document.getElementById('chart-cpu'), cpuH, '#38D9A9');
  drawChart(document.getElementById('chart-ram'), ramH, '#4FA7E8');
  const diskBars=document.getElementById('disk-bars');
  diskBars.innerHTML=(d.disks||[]).map(dk=>{
    const cls=dk.percent>=90?'danger':dk.percent>=75?'warn':'';
    const io=dk.read_mb!=null?` R:${dk.read_mb}MB W:${dk.write_mb}MB`:'';
    return `<div class="disk-bar-row">
      <div class="disk-bar-label"><span>${esc(dk.mountpoint)} (${esc(dk.fstype)})</span>
        <span>${dk.used_gb}/${dk.total_gb} GB · ${dk.percent}%${io}</span></div>
      <div class="disk-bar-track"><div class="disk-bar-fill ${cls}" style="width:${dk.percent}%"></div></div>
    </div>`;
  }).join('')||'<p class="note">No disk data</p>';
  const netIf=document.getElementById('net-interfaces');
  netIf.innerHTML=Object.entries(d.interfaces||{}).map(([name,s])=>
    `<span style="margin-right:16px">${esc(name)} — ${s.isup?'<span style="color:var(--accent)">UP</span>':'DOWN'} ${s.speed?s.speed+' Mbps':''}</span>`
  ).join('');
  renderMonitorAlerts(d.alerts);
}

let procFilterText='';
document.getElementById('proc-filter')?.addEventListener('input', e=>{ procFilterText=e.target.value.toLowerCase(); });

async function pollProcesses() {
  const d=await fetch(`/api/monitor/processes?sort=${processSort}&limit=50`).then(r=>r.json()).catch(()=>({processes:[]}));
  const tb=document.querySelector('#process-table tbody');
  const rows=(d.processes||[]).filter(p=>!procFilterText||p.name.toLowerCase().includes(procFilterText));
  tb.innerHTML=rows.map(p=>`
    <tr>
      <td>${esc(p.name)}</td><td>${p.pid}</td><td class="mono">${esc(p.user)}</td>
      <td style="color:${p.cpu_percent>50?'var(--critical)':p.cpu_percent>20?'var(--high)':'inherit'}">${p.cpu_percent}</td>
      <td style="color:${p.memory_mb>1000?'var(--high)':'inherit'}">${p.memory_mb}</td>
      <td>${esc(p.status)}</td>
      <td class="mono" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.exe)}">${esc(p.exe)}</td>
    </tr>`).join('')||'<tr><td colspan="7" class="note">No data</td></tr>';
}

['sort-cpu','sort-mem'].forEach(id=>{
  document.getElementById(id)?.addEventListener('click', ()=>{
    processSort=document.getElementById(id).dataset.sort;
    document.getElementById('sort-cpu').classList.toggle('active', processSort==='cpu');
    document.getElementById('sort-mem').classList.toggle('active', processSort==='memory');
    pollProcesses();
  });
});

function startMonitorPolling() {
  if (monitorTimer) return;
  pollSystemMetrics(); pollProcesses();
  monitorTimer=setInterval(()=>{
    if (document.getElementById('auto-refresh')?.checked!==false) { pollSystemMetrics(); pollProcesses(); }
  }, 3000);
}
function stopMonitorPolling() { if (monitorTimer){clearInterval(monitorTimer);monitorTimer=null;} }

// ═══════════════════════════════════════════════════════════
//  FILE WATCH
// ═══════════════════════════════════════════════════════════
async function loadWatchEvents() {
  const d=await fetch('/api/watch/events').then(r=>r.json()).catch(()=>({events:[],alert:null,watched_paths:[]}));
  const tb=document.querySelector('#watch-table tbody');
  tb.innerHTML=(d.events||[]).map(e=>`
    <tr class="${e.type==='created'||e.type==='modified'?'tr-high':''}">
      <td>${esc(fmtDate(e.time))}</td><td>${esc(e.type)}</td><td class="mono">${esc(e.path)}</td>
    </tr>`).join('')||'<tr><td colspan="3" class="note">No events yet.</td></tr>';
  const banner=document.getElementById('watch-alert-banner');
  banner.innerHTML=d.alert?`<div class="alert-banner"><span class="sev-tag critical">ALERT</span> ${esc(d.alert)}</div>`:'';
  const pathList=document.getElementById('watch-paths-list');
  pathList.innerHTML=(d.watched_paths||[]).map(p=>`
    <span class="chip-tag">${esc(p)}<button onclick="removeWatchPath('${esc(p)}')">×</button></span>`
  ).join('')||'<span class="note">No paths being watched.</span>';
  document.getElementById('watch-note').textContent=`Watching ${(d.watched_paths||[]).length} path(s)`;
}
document.getElementById('refresh-watch').addEventListener('click', loadWatchEvents);
document.getElementById('watch-add-btn').addEventListener('click', async ()=>{
  const p=document.getElementById('watch-path-input').value.trim();
  if (!p) return;
  const cfg=await fetch('/api/watch/config').then(r=>r.json()).catch(()=>({watched_paths:[]}));
  const paths=[...(cfg.watched_paths||[]), p];
  await fetch('/api/watch/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paths})});
  document.getElementById('watch-path-input').value='';
  loadWatchEvents();
});
async function removeWatchPath(path) {
  const cfg=await fetch('/api/watch/config').then(r=>r.json()).catch(()=>({watched_paths:[]}));
  const paths=(cfg.watched_paths||[]).filter(p=>p!==path);
  await fetch('/api/watch/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paths})});
  loadWatchEvents();
}
window.removeWatchPath=removeWatchPath;

// ═══════════════════════════════════════════════════════════
//  REPORTS
// ═══════════════════════════════════════════════════════════
function buildReportText() {
  const lines=['HSKICH - SYSTEM SECURITY REPORT', `Generated: ${new Date().toLocaleString()}`];
  if (lastScanMeta) {
    lines.push(`Scan time: ${lastScanMeta.when}`);
    lines.push(`Admin: ${lastScanMeta.isAdmin?'Yes':'No'} | Total findings: ${lastScanMeta.total}`);
  }
  lines.push('\nSUMMARY'); ['critical','high','medium','low','info'].forEach(s=>lines.push(`  ${SEV_LABEL[s]}: ${lastScanMeta?.counts?.[s]??0}`));
  lines.push('');
  ['critical','high','medium','low','info'].forEach(sev=>{
    const items=lastFindings.filter(f=>f.severity===sev);
    if (!items.length) return;
    lines.push(`${SEV_LABEL[sev].toUpperCase()} (${items.length})\n${'-'.repeat(40)}`);
    items.forEach(f=>{
      lines.push(`[${CAT_LABEL[f.category]||f.category}] ${f.title}`);
      lines.push(`  ${f.detail}`);
      lines.push(`  → ${f.recommendation}`);
      if (f.reference) lines.push(`  Ref: ${f.reference}`);
      lines.push('');
    });
  });
  return lines.join('\n');
}
function buildReportHtml() {
  if (!lastFindings.length) return '<p class="empty-state">Run a full scan first.</p>';
  let html=`<h3>Hskich — System Security Report</h3>
    <p class="note">Generated: ${new Date().toLocaleString()}${lastScanMeta?` · Scan: ${lastScanMeta.when} · ${lastScanMeta.total} finding(s)`:''}</p>`;
  ['critical','high','medium','low','info'].forEach(sev=>{
    const items=lastFindings.filter(f=>f.severity===sev);
    if (!items.length) return;
    html+=`<h3>${SEV_LABEL[sev]} (${items.length})</h3>`;
    items.forEach(f=>{
      html+=`<div class="report-finding">
        <strong>[${CAT_LABEL[f.category]||f.category}] ${esc(f.title)}</strong><br>
        ${esc(f.detail)}<br>
        <span style="color:var(--accent)">&rarr; ${esc(f.recommendation)}</span>
        ${f.reference?`<br><a href="${esc(f.reference)}" target="_blank" rel="noopener">${esc(f.reference)}</a>`:''}
      </div>`;
    });
  });
  return html;
}
document.getElementById('generate-report-btn').addEventListener('click', ()=>{
  document.getElementById('report-preview').innerHTML=buildReportHtml();
  document.getElementById('report-note').textContent=lastFindings.length?'Report ready.':'';
});
document.getElementById('print-report-btn').addEventListener('click', ()=>{
  if (!lastFindings.length){document.getElementById('report-note').textContent='Generate the report first.';return;}
  window.print();
});
document.getElementById('download-report-btn').addEventListener('click', ()=>{
  if (!lastFindings.length){document.getElementById('report-note').textContent='Generate the report first.';return;}
  const blob=new Blob([buildReportText()],{type:'text/plain'});
  const a=Object.assign(document.createElement('a'),{href:URL.createObjectURL(blob),
    download:`hskich-report-${new Date().toISOString().slice(0,10)}.txt`});
  document.body.appendChild(a); a.click(); a.remove();
});

// ═══════════════════════════════════════════════════════════
//  INIT
// ═══════════════════════════════════════════════════════════
const iv = document.body.dataset.initialView;
if (iv && document.getElementById(`view-${iv}`)) switchView(iv, false);
