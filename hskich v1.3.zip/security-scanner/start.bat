@echo off
setlocal enabledelayedexpansion
title Hskich - Local Security Watch
cd /d "%~dp0"

echo ============================================
echo   Hskich - Local Security Watch
echo ============================================
echo.

set PY_CMD=
where py >nul 2>&1
if errorlevel 1 goto try_python
set PY_CMD=py -3
goto have_python

:try_python
where python >nul 2>&1
if errorlevel 1 goto no_python
set PY_CMD=python

:have_python
if "%PY_CMD%"=="" goto no_python
echo Using: %PY_CMD%
%PY_CMD% --version
if errorlevel 1 goto python_broken
echo.
goto check_venv

:no_python
echo [ERROR] No working Python installation was found.
echo.
echo Install Python 3.10+ from https://www.python.org/downloads/
echo IMPORTANT: check "Add python.exe to PATH" during setup, then run this file again.
echo.
pause
exit /b 1

:python_broken
echo.
echo [ERROR] %PY_CMD% was found on PATH but does not actually run.
echo.
echo This usually means Windows points "python" at the Microsoft Store stub.
echo Fix: Settings, then Apps, then Advanced app settings, then App execution
echo aliases - turn OFF python.exe and python3.exe, then re-run this file.
echo Or reinstall Python from python.org with "Add python.exe to PATH" checked.
echo.
pause
exit /b 1

:check_venv
if exist "venv\Scripts\python.exe" goto venv_ready
echo [1/3] First run: creating a local Python environment...
%PY_CMD% -m venv venv
if errorlevel 1 goto venv_failed
goto venv_ready

:venv_failed
echo.
echo [ERROR] Could not create the virtual environment. Possible causes:
echo   - The venv module is missing from this Python install
echo   - This folder is inside OneDrive or another cloud-synced or locked folder
echo   - Antivirus is blocking script execution
echo   - Not enough permissions to write to this folder
echo.
echo Try moving this whole folder to a plain local path such as C:\Hskich
echo and running start.bat again from there.
echo.
pause
exit /b 1

:venv_ready
echo [1/3] Python environment ready.
set VENV_PY=venv\Scripts\python.exe

echo [2/3] Checking dependencies (Flask, psutil, watchdog)...
"%VENV_PY%" -m pip install --quiet --upgrade pip
"%VENV_PY%" -m pip install --quiet -r requirements.txt
if errorlevel 1 goto deps_failed
goto deps_ready

:deps_failed
echo.
echo [ERROR] pip install failed. See the errors printed above.
echo.
pause
exit /b 1

:deps_ready
echo [2/3] Dependencies ready.
echo [3/3] Starting Hskich...
echo.
echo NOTE: for complete results - firewall, security log, update history -
echo re-run this file as Administrator: right-click it, then "Run as administrator".
echo.

"%VENV_PY%" launcher.py
if errorlevel 1 goto launch_failed
exit /b 0

:launch_failed
echo.
echo [ERROR] Hskich closed with an error - see the message above.
echo.
echo If you see "tkinter" or "_tkinter" mentioned, your Python install is
echo missing the Tk/Tcl component. Reinstall Python from python.org and make
echo sure "tcl/tk and IDLE" is checked in the optional features during setup.
echo.
pause
exit /b 1
