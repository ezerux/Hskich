@echo off
setlocal enabledelayedexpansion
title Build Hskich Standalone Executable (.exe)
cd /d "%~dp0"

echo ========================================================
echo   Building Hskich Standalone Desktop Executable (.exe)
echo ========================================================
echo.

set VENV_PY=venv\Scripts\python.exe
if not exist "%VENV_PY%" (
    echo [ERROR] Virtual environment not found. Please run start.bat or start_desktop.bat first.
    pause
    exit /b 1
)

echo [1/3] Installing PyInstaller and desktop requirements...
"%VENV_PY%" -m pip install --upgrade pip
"%VENV_PY%" -m pip install pyinstaller -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install build dependencies.
    pause
    exit /b 1
)

echo.
echo [2/3] Building Hskich.exe...
"%VENV_PY%" -m PyInstaller ^
    --noconsole ^
    --name="Hskich" ^
    --add-data="templates;templates" ^
    --add-data="static;static" ^
    --add-data="hskich_config.json;." ^
    --hidden-import="flask" ^
    --hidden-import="psutil" ^
    --hidden-import="watchdog" ^
    --hidden-import="webview" ^
    --hidden-import="scanner" ^
    --clean ^
    --noconfirm ^
    desktop.py

if errorlevel 1 (
    echo.
    echo [ERROR] PyInstaller build failed.
    pause
    exit /b 1
)

echo.
echo [3/3] Build complete!
echo Your standalone desktop application is located at:
echo   dist\Hskich\Hskich.exe
echo.
echo You can create a desktop shortcut to 'dist\Hskich\Hskich.exe' and launch it directly!
echo ========================================================
pause
