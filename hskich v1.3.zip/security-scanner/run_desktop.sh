#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "=== Hskich Desktop Application ==="
python3 desktop.py "$@"
