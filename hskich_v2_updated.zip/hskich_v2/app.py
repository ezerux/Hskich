"""
Hskich - Local Security Audit Dashboard.
Run as Administrator for complete results.
Everything runs locally; nothing leaves this machine.
"""
import ctypes
import os
import platform
import sys
from datetime import datetime

from flask import Flask, jsonify, render_template, request

from scanner import (
    network_scan, system_scan, defender_scan, event_logs,
    clamav_scan, monitor, registry_scan, hash_scan, file_watch, config_store
)
from scanner import network_advanced, file_scanner
from scanner.risk_engine import aggregate

app = Flask(__name__)
_latest_scan = {"ran_at": None, "result": None}

def is_admin():
    if platform.system() != "Windows":
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except OSError:
        return False

def run_full_scan():
    all_findings, details = [], {}
    for module in (network_scan, system_scan, defender_scan, clamav_scan, registry_scan, event_logs):
        try:
            f, extra = module.run()
        except Exception as exc:
            f, extra = [], {"error": str(exc)}
        all_findings.extend(f)
        details[module.__name__.rsplit(".", 1)[-1]] = extra
    try:
        net_f = network_advanced.scan_findings()
        all_findings.extend(net_f)
    except Exception:
        pass
    result = aggregate(all_findings)
    result["details"] = details
    result["ran_at"]  = datetime.now().isoformat(timespec="seconds")
    result["is_admin"] = is_admin()
    _latest_scan["ran_at"]  = result["ran_at"]
    _latest_scan["result"]  = result
    return result

# ── Pages ──────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html",
        is_admin=is_admin(), is_windows=platform.system()=="Windows",
        initial_view=request.args.get("view","overview"))

# ── Scan ───────────────────────────────────────────────
@app.route("/api/scan", methods=["POST"])
def api_scan():
    return jsonify(run_full_scan())

@app.route("/api/scan", methods=["GET"])
def api_scan_latest():
    if not _latest_scan["result"]:
        return jsonify({"ran_at":None,"findings":[],"counts":{},"total":0,"details":{}})
    return jsonify(_latest_scan["result"])

# ── Logs ───────────────────────────────────────────────
@app.route("/api/logs")
def api_logs():
    entries, err = event_logs.get_recent_logs(max_events=300)
    return jsonify({"entries": entries, "error": err})

# ── Defender ───────────────────────────────────────────
@app.route("/api/defender/scan", methods=["POST"])
def api_defender_scan():
    ok, err = defender_scan.trigger_quick_scan()
    if not ok:
        return jsonify({"started":False,"error":err}), 500
    return jsonify({"started":True,"note":"Quick scan started. Check Windows Security for progress."})

# ── ClamAV ─────────────────────────────────────────────
@app.route("/api/clamav/status")
def api_clamav_status():
    _, extra = clamav_scan.run()
    return jsonify(extra["clamav"])

@app.route("/api/clamav/update", methods=["POST"])
def api_clamav_update():
    info = clamav_scan.detect()
    if not info["clamscan"]:
        return jsonify({"started":False,"error":"ClamAV is not installed"}), 400
    ok, err = clamav_scan.run_update(info["freshclam"])
    if not ok:
        return jsonify({"started":False,"error":err}), 500
    return jsonify({"started":True,"note":"Updating ClamAV database in the background (1-2 min)."})

@app.route("/api/clamav/scan", methods=["POST"])
def api_clamav_scan():
    info = clamav_scan.detect()
    if not info["clamscan"]:
        return jsonify({"error":"ClamAV is not installed"}), 400
    body = request.get_json(silent=True) or {}
    paths = body.get("paths") or []
    path = body.get("path")
    if path:
        paths = [path]
    targets = [p.strip() for p in paths if isinstance(p, str) and p.strip()]
    if not targets:
        targets = None
    out, err, infected = clamav_scan.run_scan(info["clamscan"], targets)
    if err:
        return jsonify({"error":err}), 500
    return jsonify({
        "infected": infected,
        "scanned":  targets or clamav_scan.default_scan_paths(),
        "raw_tail": (out or "")[-3000:],
        "targets": targets or clamav_scan.default_scan_paths(),
    })

# ── File Scanner ───────────────────────────────────────
@app.route("/api/filescan", methods=["POST"])
def api_filescan():
    body = request.get_json(silent=True) or {}
    folder = body.get("folder","")
    if not folder:
        return jsonify({"error":"No folder specified"}), 400
    clamav_info = clamav_scan.detect()
    f, files = file_scanner.scan_folder(folder)
    # also run ClamAV on this folder if available
    clam_infected = []
    if clamav_info["clamscan"]:
        _, cerr, clam_infected = clamav_scan.run_scan(clamav_info["clamscan"], [folder])
    return jsonify({
        "findings":  f,
        "files":     files[:500],
        "total_files": len(files),
        "clamav_infected": clam_infected,
    })

# ── Registry ───────────────────────────────────────────
@app.route("/api/registry/scan")
def api_registry_scan():
    f, extra = registry_scan.run()
    return jsonify({"findings": f, "autoruns": extra["autoruns"]})

# ── Hash / Process integrity ───────────────────────────
@app.route("/api/hash/check", methods=["POST"])
def api_hash_check():
    body = request.get_json(silent=True) or {}
    auth_key = config_store.get_malwarebazaar_key()
    f, results = hash_scan.check_processes(auth_key, limit=body.get("limit",15))
    return jsonify({"findings":f,"results":results,"has_key":bool(auth_key)})

# ── Network advanced ───────────────────────────────────
@app.route("/api/network/connections")
def api_network_connections():
    conns, err = network_advanced.get_active_connections()
    return jsonify({"connections": conns, "error": err})

@app.route("/api/network/firewall")
def api_network_firewall():
    rules, err = network_advanced.get_firewall_rules()
    return jsonify({"rules": rules, "error": err})

@app.route("/api/network/perprocess")
def api_network_perprocess():
    return jsonify({"io": network_advanced.get_per_process_net()})

# ── File Watch ─────────────────────────────────────────
@app.route("/api/watch/events")
def api_watch_events():
    return jsonify({
        "events":        file_watch.get_events(150),
        "alert":         file_watch.get_alert_state(),
        "watched_paths": file_watch.get_watched_paths(),
    })

@app.route("/api/watch/clear", methods=["POST"])
def api_watch_clear():
    file_watch.clear_events()
    return jsonify({"ok": True})

@app.route("/api/watch/config", methods=["GET"])
def api_watch_config_get():
    return jsonify({
        "watched_paths":  file_watch.get_watched_paths(),
        "default_paths":  file_watch.default_watch_paths(),
    })

@app.route("/api/watch/config", methods=["POST"])
def api_watch_config_set():
    body  = request.get_json(silent=True) or {}
    paths = [p.strip() for p in body.get("paths",[]) if p.strip()]
    valid = [p for p in paths if os.path.isdir(p)]
    config_store.save_config({"watch_paths": valid})
    file_watch.restart(valid or None)
    return jsonify({"watched_paths": file_watch.get_watched_paths(), "invalid": list(set(paths)-set(valid))})

# ── Monitoring ─────────────────────────────────────────
@app.route("/api/monitor/system")
def api_monitor_system():
    try:
        return jsonify(monitor.get_system_metrics())
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500

@app.route("/api/monitor/processes")
def api_monitor_processes():
    sort_by = request.args.get("sort","cpu")
    limit   = request.args.get("limit",40,type=int)
    try:
        return jsonify({"processes": monitor.get_processes(limit=limit, sort_by=sort_by)})
    except Exception as exc:
        return jsonify({"error":str(exc)}), 500

# ── Settings ───────────────────────────────────────────
@app.route("/api/settings", methods=["GET"])
def api_settings_get():
    cfg = config_store.load_config()
    return jsonify({
        "has_malwarebazaar_key": bool(cfg.get("malwarebazaar_auth_key")),
        "watch_paths": cfg.get("watch_paths"),
        "clamav_db_path": cfg.get("clamav_db_path", ""),
    })

@app.route("/api/settings", methods=["POST"])
def api_settings_set():
    body = request.get_json(silent=True) or {}
    updates = {}
    if "malwarebazaar_auth_key" in body:
        updates["malwarebazaar_auth_key"] = body["malwarebazaar_auth_key"].strip()
    if "clamav_db_path" in body:
        updates["clamav_db_path"] = body["clamav_db_path"].strip()
    if updates:
        config_store.save_config(updates)
    return jsonify({"saved":True})

if __name__ == "__main__":
    if platform.system() != "Windows":
        print("Warning: built for Windows. Some checks will be skipped.", file=sys.stderr)
    if not is_admin():
        print("Note: not Administrator. Re-launch elevated for complete results.", file=sys.stderr)
    file_watch.start(config_store.get_watch_paths())
    app.run(host="127.0.0.1", port=5000, debug=False)

# ── NEW IMPORTS (appended) ──────────────────────────────────
from scanner import hardware_scan, driver_scan
from scanner import clamav_profiles as clam_profiles

# ── HARDWARE ────────────────────────────────────────────────
@app.route("/api/hardware/info")
def api_hw_info():
    return jsonify(hardware_scan.get_system_info())

@app.route("/api/hardware/battery")
def api_hw_battery():
    return jsonify({"battery": hardware_scan.get_battery_info()})

@app.route("/api/hardware/disks")
def api_hw_disks():
    f, disks = hardware_scan.get_disk_health()
    smart    = hardware_scan.get_disk_smart_wmi()
    return jsonify({"findings": f, "disks": disks, "smart": smart})

@app.route("/api/hardware/ram")
def api_hw_ram():
    f, modules = hardware_scan.get_ram_modules()
    return jsonify({"findings": f, "modules": modules})

@app.route("/api/hardware/gpu")
def api_hw_gpu():
    f, gpus = hardware_scan.get_gpu_detail()
    return jsonify({"findings": f, "gpus": gpus})

@app.route("/api/hardware/stress/start", methods=["POST"])
def api_stress_start():
    body    = request.get_json(silent=True) or {}
    path    = body.get("path", os.environ.get("TEMP", "C:\\Temp"))
    size_mb = int(body.get("size_mb", 256))
    ok, err = hardware_scan.start_stress_test(path, size_mb)
    if not ok:
        return jsonify({"started": False, "error": err}), 400
    return jsonify({"started": True, "path": path, "size_mb": size_mb})

@app.route("/api/hardware/stress/status")
def api_stress_status():
    return jsonify(hardware_scan.get_stress_state())

# ── DRIVERS ─────────────────────────────────────────────────
@app.route("/api/drivers/scan")
def api_drivers_scan():
    f, drivers = driver_scan.scan_drivers()
    return jsonify({"findings": f, "drivers": drivers})

# ── CLAMAV PROFILES ─────────────────────────────────────────
@app.route("/api/clamav/profiles")
def api_clamav_profiles():
    return jsonify({
        "profiles": clam_profiles.PROFILES,
        "db_stats": clam_profiles.get_db_stats(),
    })

@app.route("/api/clamav/scan/profile", methods=["POST"])
def api_clamav_scan_profile():
    body    = request.get_json(silent=True) or {}
    profile = body.get("profile", "quick")
    extras  = body.get("extra_paths", [])
    out, err, infected, scanned = clam_profiles.run_profile_scan(profile, extras)
    if err:
        return jsonify({"error": err}), 500
    return jsonify({
        "profile":  profile,
        "infected": infected,
        "scanned":  scanned,
        "raw_tail": (out or "")[-4000:],
    })
