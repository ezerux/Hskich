@echo off
setlocal enabledelayedexpansion
title Zenith Local - Security Dashboard
cd /d "%~dp0"

echo ============================================
echo   Zenith Local - Security Dashboard
echo ============================================
echo.

REM ── Find Python ─────────────────────────────────
set PY_CMD=
where py >nul 2>&1
if not errorlevel 1 ( set PY_CMD=py -3 ) else (
    where python >nul 2>&1
    if not errorlevel 1 ( set PY_CMD=python )
)

if "%PY_CMD%"=="" goto no_python
%PY_CMD% --version >nul 2>&1
if errorlevel 1 goto python_broken
goto check_venv

:no_python
echo [ERROR] Python not found.
echo.
echo Please install Python 3.10+ from https://www.python.org/downloads/
echo IMPORTANT: check "Add python.exe to PATH" during setup.
echo.
pause & exit /b 1

:python_broken
echo [ERROR] Python was found but does not run.
echo.
echo Go to Settings - Apps - Advanced app settings - App execution aliases
echo and turn OFF python.exe and python3.exe, then re-run this file.
echo.
pause & exit /b 1

REM ── Virtual environment ──────────────────────────
:check_venv
if exist "venv\Scripts\python.exe" goto venv_ready

echo [1/3] Creating Python virtual environment...
%PY_CMD% -m venv venv
if errorlevel 1 (
    echo.
    echo [ERROR] Could not create venv. Try moving this folder to C:\ZenithLocal
    echo.
    pause & exit /b 1
)

:venv_ready
echo [1/3] Python environment ready.
set VENV_PY=venv\Scripts\python.exe

REM ── Dependencies ─────────────────────────────────
echo [2/3] Checking dependencies...
"%VENV_PY%" -m pip install --quiet --upgrade pip
"%VENV_PY%" -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] pip install failed. See errors above.
    echo.
    pause & exit /b 1
)
echo [2/3] Dependencies ready.

REM ── Launch ───────────────────────────────────────
echo [3/3] Starting Zenith Local...
echo.
echo NOTE: Right-click this file and "Run as administrator"
echo for complete results (firewall, security log, update history).
echo.

"%VENV_PY%" launcher.py
if errorlevel 1 (
    echo.
    echo [ERROR] Zenith Local closed with an error.
    echo If you see "tkinter" mentioned, reinstall Python from python.org
    echo and check "tcl/tk and IDLE" in optional features.
    echo.
    pause
)
exit /b 0
