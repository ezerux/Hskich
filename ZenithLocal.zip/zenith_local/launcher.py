"""
Zenith Local (Հսկիչ) - Desktop launcher.
Gives a plain double-click GUI for people who don't want to touch PowerShell:
Install button -> pip install -r requirements.txt
Run button     -> starts app.py and opens the dashboard in the default browser
"""
import os
import queue
import subprocess
import sys
import threading
import time
import webbrowser
import tkinter as tk
from tkinter import ttk, scrolledtext

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable
SERVER_URL = "http://127.0.0.1:5000"

BG = "#0D1210"
SURFACE = "#141B19"
BORDER = "#263129"
TEXT = "#DCE6E1"
MUTED = "#7C9089"
ACCENT = "#38D9A9"

NO_WINDOW_FLAGS = {}
if sys.platform == "win32":
    NO_WINDOW_FLAGS["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    NO_WINDOW_FLAGS["startupinfo"] = si


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Zenith Local")
        self.geometry("640x460")
        self.configure(bg=BG)
        self.minsize(560, 400)

        self.server_process = None
        self.log_queue = queue.Queue()

        self._build_ui()
        self.after(150, self._drain_log_queue)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        header = tk.Frame(self, bg=BG)
        header.pack(fill="x", padx=24, pady=(20, 10))

        mark = tk.Frame(header, bg=ACCENT, width=10, height=10)
        mark.pack(side="left", padx=(0, 10), pady=6)
        tk.Label(header, text="Zenith Local", font=("Segoe UI", 18, "bold"), bg=BG, fg=TEXT).pack(side="left")
        tk.Label(header, text="Local Security Watch", font=("Segoe UI", 10), bg=BG, fg=MUTED).pack(side="left", padx=(10, 0), pady=(6, 0))

        self.status_var = tk.StringVar(value="Ready - not started")
        tk.Label(self, textvariable=self.status_var, font=("Consolas", 10), bg=BG, fg=MUTED, anchor="w").pack(fill="x", padx=24)

        btn_row = tk.Frame(self, bg=BG)
        btn_row.pack(fill="x", padx=24, pady=14)

        self.install_btn = tk.Button(
            btn_row, text="Install", command=self.on_install,
            bg=SURFACE, fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
            relief="flat", padx=18, pady=8, font=("Segoe UI", 10, "bold"),
        )
        self.install_btn.pack(side="left", padx=(0, 8))

        self.run_btn = tk.Button(
            btn_row, text="Run Desktop App", command=lambda: self.on_run("desktop"),
            bg=ACCENT, fg="#06231A", activebackground="#2FC498", activeforeground="#06231A",
            relief="flat", padx=20, pady=8, font=("Segoe UI", 10, "bold"),
        )
        self.run_btn.pack(side="left", padx=8)

        self.browser_btn = tk.Button(
            btn_row, text="Browser", command=lambda: self.on_run("browser"),
            bg=SURFACE, fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
            relief="flat", padx=14, pady=8, font=("Segoe UI", 10),
        )
        self.browser_btn.pack(side="left", padx=(0, 8))

        self.stop_btn = tk.Button(
            btn_row, text="Stop", command=self.on_stop, state="disabled",
            bg=SURFACE, fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
            relief="flat", padx=18, pady=8, font=("Segoe UI", 10, "bold"),
        )
        self.stop_btn.pack(side="left", padx=8)

        self.open_btn = tk.Button(
            btn_row, text="Open in browser", command=lambda: webbrowser.open(SERVER_URL),
            bg=SURFACE, fg=ACCENT, activebackground=BORDER, activeforeground=ACCENT,
            relief="flat", padx=14, pady=8, font=("Segoe UI", 10),
        )
        self.open_btn.pack(side="right")

        tk.Label(self, text="Log", font=("Segoe UI", 9), bg=BG, fg=MUTED, anchor="w").pack(fill="x", padx=24, pady=(6, 2))

        self.log_box = scrolledtext.ScrolledText(
            self, bg=SURFACE, fg=TEXT, insertbackground=TEXT, relief="flat",
            font=("Consolas", 9), height=16, borderwidth=0,
        )
        self.log_box.pack(fill="both", expand=True, padx=24, pady=(0, 20))
        self.log_box.configure(state="disabled")

    def _log(self, line):
        self.log_queue.put(line)

    def _drain_log_queue(self):
        try:
            while True:
                line = self.log_queue.get_nowait()
                self.log_box.configure(state="normal")
                self.log_box.insert("end", line + "\n")
                self.log_box.see("end")
                self.log_box.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(150, self._drain_log_queue)

    def _set_status(self, text):
        self.status_var.set(text)

    # --- Install ---
    def on_install(self):
        self.install_btn.config(state="disabled")
        self._set_status("Installing...")
        threading.Thread(target=self._run_install, daemon=True).start()

    def _run_install(self):
        req = os.path.join(BASE_DIR, "requirements.txt")
        cmd = [PYTHON, "-m", "pip", "install", "-r", req]
        self._log(f"$ {' '.join(cmd)}")
        try:
            proc = subprocess.Popen(
                cmd, cwd=BASE_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, **NO_WINDOW_FLAGS,
            )
            for line in proc.stdout:
                self._log(line.rstrip())
            proc.wait()
            if proc.returncode == 0:
                self._log("Install finished successfully.")
                self._set_status("Installed - click Run")
            else:
                self._log(f"pip install failed (exit code {proc.returncode}).")
                self._set_status("Install error - see the log")
        except Exception as exc:
            self._log(f"Error: {exc}")
            self._set_status("Install error")
        finally:
            self.install_btn.config(state="normal")

    # --- Run ---
    def on_run(self, mode="desktop"):
        if self.server_process is not None:
            self._log("The application/server is already running.")
            return
        self.run_btn.config(state="disabled")
        self.browser_btn.config(state="disabled")
        status_msg = "Starting Desktop Application..." if mode == "desktop" else "Starting server (Browser)..."
        self._set_status(status_msg)
        threading.Thread(target=self._run_server, args=(mode,), daemon=True).start()

    def _run_server(self, mode="desktop"):
        target_script = "desktop.py" if mode == "desktop" else "app.py"
        target_py = os.path.join(BASE_DIR, target_script)
        self._log(f"$ {PYTHON} {target_py}")
        try:
            self.server_process = subprocess.Popen(
                [PYTHON, target_py], cwd=BASE_DIR,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                **NO_WINDOW_FLAGS,
            )
        except Exception as exc:
            self._log(f"Could not start: {exc}")
            self._set_status("Did not start")
            self.run_btn.config(state="normal")
            self.browser_btn.config(state="normal")
            return

        self.stop_btn.config(state="normal")
        if mode == "desktop":
            self._set_status("Desktop Application is running")
        else:
            self._set_status("Server running - http://127.0.0.1:5000")
            time.sleep(1.2)
            webbrowser.open(SERVER_URL)

        for line in self.server_process.stdout:
            self._log(line.rstrip())

        # process ended
        self.server_process = None
        self.run_btn.config(state="normal")
        self.browser_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self._set_status("Application stopped")

    def on_stop(self):
        if self.server_process is not None:
            self._log("Stopping the server...")
            self.server_process.terminate()
        self.stop_btn.config(state="disabled")

    def _on_close(self):
        if self.server_process is not None:
            try:
                self.server_process.terminate()
            except Exception:
                pass
        self.destroy()


if __name__ == "__main__":
    Launcher().mainloop()
