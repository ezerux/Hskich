"""Hardware health scanner: Disk S.M.A.R.T., CPU/RAM/GPU diagnostics,
disk stress test, battery health. All via WMI/PowerShell on Windows."""
import os
import time
import threading
from .risk_engine import finding
from .ps import run_ps_safe

# ── SYSTEM INFO ────────────────────────────────────────────
def get_system_info():
    cs, _ = run_ps_safe(
        "Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,"
        "TotalPhysicalMemory,NumberOfLogicalProcessors,NumberOfProcessors,SystemType,"
        "DomainRole,PartOfDomain,Workgroup | ConvertTo-Json", timeout=20)
    os_info, _ = run_ps_safe(
        "Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,"
        "BuildNumber,OSArchitecture,InstallDate,LastBootUpTime,FreePhysicalMemory,"
        "TotalVisibleMemorySize,FreeVirtualMemory,TotalVirtualMemorySize | ConvertTo-Json", timeout=20)
    cpu, _ = run_ps_safe(
        "Get-CimInstance Win32_Processor | Select-Object Name,Manufacturer,"
        "MaxClockSpeed,CurrentClockSpeed,NumberOfCores,NumberOfLogicalProcessors,"
        "L2CacheSize,L3CacheSize,Architecture,SocketDesignation | ConvertTo-Json", timeout=20)
    gpu, _ = run_ps_safe(
        "Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,"
        "DriverVersion,DriverDate,CurrentHorizontalResolution,CurrentVerticalResolution,"
        "CurrentRefreshRate,VideoProcessor,Status | ConvertTo-Json", timeout=20)
    bios, _ = run_ps_safe(
        "Get-CimInstance Win32_BIOS | Select-Object Manufacturer,Name,Version,"
        "ReleaseDate,SerialNumber,SMBIOSBIOSVersion | ConvertTo-Json", timeout=20)
    mobo, _ = run_ps_safe(
        "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,"
        "SerialNumber,Version | ConvertTo-Json", timeout=20)

    def to_list(d):
        return d if isinstance(d, list) else ([d] if d else [])

    return {
        "computer": cs or {},
        "os": os_info or {},
        "cpu": to_list(cpu),
        "gpu": to_list(gpu),
        "bios": bios or {},
        "motherboard": mobo or {},
    }

# ── BATTERY ────────────────────────────────────────────────
def get_battery_info():
    bat, _ = run_ps_safe(
        "Get-CimInstance Win32_Battery | Select-Object Name,Status,BatteryStatus,"
        "EstimatedRunTime,EstimatedChargeRemaining,DesignCapacity,FullChargeCapacity,"
        "Chemistry,DeviceID | ConvertTo-Json", timeout=15)
    if not bat:
        return None
    b = bat if isinstance(bat, dict) else (bat[0] if bat else {})
    design = b.get("DesignCapacity") or 0
    full   = b.get("FullChargeCapacity") or 0
    health_pct = round(full / design * 100, 1) if design and full else None
    b["health_percent"] = health_pct
    CHEMISTRY = {1:"Other",2:"Unknown",3:"Lead Acid",4:"NiCad",5:"NiMH",6:"Li-Ion",7:"Zinc Air",8:"Li Polymer"}
    b["chemistry_name"] = CHEMISTRY.get(b.get("Chemistry"), "Unknown")
    STATUS = {1:"Discharging",2:"AC (plugged in)",3:"Fully charged",4:"Low",
              5:"Critical",6:"Charging",7:"Charging+High",8:"Charging+Low",
              9:"Charging+Critical",10:"Undefined",11:"Partially charged"}
    b["battery_status_name"] = STATUS.get(b.get("BatteryStatus"), "Unknown")
    return b

# ── DISK HEALTH (S.M.A.R.T. via Get-PhysicalDisk) ─────────
def get_disk_health():
    data, _ = run_ps_safe(
        "Get-PhysicalDisk | Select-Object FriendlyName,MediaType,HealthStatus,"
        "OperationalStatus,Size,AllocatedSize,SpindleSpeed,"
        "FirmwareVersion,UniqueId | ConvertTo-Json -Depth 2", timeout=20)
    if not data:
        return [], []
    disks = data if isinstance(data, list) else [data]
    findings = []
    for d in disks:
        health = str(d.get("HealthStatus", "")).lower()
        status = str(d.get("OperationalStatus", "")).lower()
        name   = d.get("FriendlyName", "Disk")
        size_gb = round((d.get("Size") or 0) / (1024**3), 1)
        d["size_gb"] = size_gb
        if health == "unhealthy":
            findings.append(finding(
                "hardware", "critical", f"Disk UNHEALTHY: {name}",
                f"{name} ({size_gb} GB) reports UNHEALTHY S.M.A.R.T. status. Data loss risk is imminent.",
                "Back up all data immediately and replace this drive.",
                reference="https://learn.microsoft.com/en-us/windows-server/storage/storage-spaces/storage-spaces-fault-tolerance",
            ))
        elif health == "warning":
            findings.append(finding(
                "hardware", "high", f"Disk WARNING: {name}",
                f"{name} ({size_gb} GB) reports WARNING S.M.A.R.T. status. Drive may fail soon.",
                "Run a full disk check (chkdsk) and plan a backup and replacement.",
            ))
        if status not in ("ok", "online", ""):
            findings.append(finding(
                "hardware", "medium", f"Disk operational issue: {name}",
                f"Operational status is '{d.get('OperationalStatus')}' instead of OK.",
                "Check Disk Management (diskmgmt.msc) for errors.",
            ))
    return findings, disks

def get_disk_smart_wmi():
    """Pull raw S.M.A.R.T. attribute data via WMI MSStorageDriver_FailurePredictStatus."""
    data, _ = run_ps_safe(
        "Get-WmiObject -Namespace root\\wmi -Class MSStorageDriver_FailurePredictStatus "
        "-ErrorAction SilentlyContinue | Select-Object InstanceName,PredictFailure,Reason | ConvertTo-Json",
        timeout=20)
    if not data:
        return []
    return data if isinstance(data, list) else [data]

# ── RAM ────────────────────────────────────────────────────
def get_ram_modules():
    data, _ = run_ps_safe(
        "Get-CimInstance Win32_PhysicalMemory | Select-Object BankLabel,DeviceLocator,"
        "Capacity,Speed,Manufacturer,PartNumber,SerialNumber,MemoryType,"
        "FormFactor,DataWidth,TotalWidth,ConfiguredClockSpeed | ConvertTo-Json", timeout=15)
    if not data:
        return [], []
    modules = data if isinstance(data, list) else [data]
    findings = []
    MEMTYPE = {0:"Unknown",1:"Other",2:"DRAM",3:"Sync DRAM",11:"Flash",12:"EEPROM",
               17:"SDRAM",18:"SGRAM",20:"DDR",21:"DDR2",22:"DDR2 FB-DIMM",
               24:"DDR3",25:"FBD2",26:"DDR4"}
    FORMFAC = {0:"Unknown",8:"DIMM",12:"SODIMM",13:"TSOP",9:"Proprietary"}
    for m in modules:
        m["capacity_gb"]  = round((m.get("Capacity") or 0) / (1024**3), 1)
        m["memory_type_name"]  = MEMTYPE.get(m.get("MemoryType"), "Unknown")
        m["form_factor_name"]  = FORMFAC.get(m.get("FormFactor"), "Unknown")
        speed = m.get("ConfiguredClockSpeed") or m.get("Speed")
        if speed and speed < 1600:
            findings.append(finding(
                "hardware", "low", f"Slow RAM in slot {m.get('DeviceLocator','?')}",
                f"RAM speed is {speed} MHz — modern systems typically run at 2400+ MHz.",
                "This may cause performance bottlenecks, especially under load.",
            ))
    return findings, modules

# ── GPU ────────────────────────────────────────────────────
def get_gpu_detail():
    data, _ = run_ps_safe(
        "Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,"
        "DriverVersion,DriverDate,CurrentHorizontalResolution,CurrentVerticalResolution,"
        "CurrentRefreshRate,VideoProcessor,Status,DeviceID | ConvertTo-Json", timeout=15)
    if not data:
        return [], []
    gpus = data if isinstance(data, list) else [data]
    findings = []
    for g in gpus:
        ram_gb = round((g.get("AdapterRAM") or 0) / (1024**3), 1)
        g["vram_gb"] = ram_gb
        status = str(g.get("Status","")).lower()
        if status not in ("ok",""):
            findings.append(finding(
                "hardware", "high", f"GPU status not OK: {g.get('Name','GPU')}",
                f"Status reported as '{g.get('Status')}'. This may indicate a driver or hardware problem.",
                "Update the GPU driver or check Device Manager for errors.",
            ))
    return findings, gpus

# ── DISK STRESS TEST (lightweight) ────────────────────────
_stress_state = {"running": False, "result": None, "error": None, "started": None}

def get_stress_state():
    return dict(_stress_state)

def _run_stress(path, size_mb):
    import tempfile, os, time, hashlib
    _stress_state["running"] = True
    _stress_state["result"]  = None
    _stress_state["error"]   = None
    _stress_state["started"] = time.time()
    try:
        test_file = os.path.join(path, "__hskich_stress_test__.tmp")
        data = os.urandom(1024 * 1024)  # 1 MB block
        chunks = size_mb
        # WRITE
        t0 = time.time()
        with open(test_file, "wb") as f:
            for _ in range(chunks):
                f.write(data)
        write_s = time.time() - t0
        write_mb_s = round(size_mb / write_s, 1)
        # READ + verify first chunk hash
        t0 = time.time()
        with open(test_file, "rb") as f:
            first = f.read(1024 * 1024)
            while f.read(1024 * 1024):
                pass
        read_s = time.time() - t0
        read_mb_s = round(size_mb / read_s, 1)
        os.remove(test_file)
        _stress_state["result"] = {
            "path": path, "size_mb": size_mb,
            "write_mb_s": write_mb_s, "write_s": round(write_s, 2),
            "read_mb_s":  read_mb_s,  "read_s":  round(read_s, 2),
            "verdict": "PASS" if read_mb_s > 10 else "SLOW",
        }
    except Exception as exc:
        _stress_state["error"] = str(exc)
        try: os.remove(test_file)
        except: pass
    finally:
        _stress_state["running"] = False

def start_stress_test(path, size_mb=256):
    if _stress_state["running"]:
        return False, "Stress test already running"
    if not os.path.isdir(path):
        return False, f"Path does not exist: {path}"
    t = threading.Thread(target=_run_stress, args=(path, size_mb), daemon=True)
    t.start()
    return True, None

def run():
    findings = []
    df, _ = get_disk_health()
    findings.extend(df)
    rf, _ = get_ram_modules()
    findings.extend(rf)
    gf, _ = get_gpu_detail()
    findings.extend(gf)
    return findings, {}
